import{default as t}from"../components/error.svelte-0882e39e.js";export{t as component};
