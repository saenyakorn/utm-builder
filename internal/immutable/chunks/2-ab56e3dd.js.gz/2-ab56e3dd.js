import{default as t}from"../components/pages/_page.svelte-9b9efc34.js";export{t as component};
