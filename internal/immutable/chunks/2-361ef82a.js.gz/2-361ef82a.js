import{default as t}from"../components/pages/_page.svelte-818a2550.js";export{t as component};
