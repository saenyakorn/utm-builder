import{default as t}from"../components/pages/_page.svelte-da17054d.js";export{t as component};
